package com.legacy.superheroes.Repository

import android.app.Application

class SearchActivityRepository(application: Application) {

}