package com.legacy.superheroes.ViewModel

import android.app.Application
import androidx.lifecycle.AndroidViewModel

class SearchActivityViewModel(application: Application): AndroidViewModel(application) {


}