package com.legacy.superheroes.Repository

import android.app.Application

class DetailActivityRepository(application: Application) {

}
