package com.legacy.superheroes.Model

data class Connections(
    val groupAffiliation: String,
    val relatives: String
)