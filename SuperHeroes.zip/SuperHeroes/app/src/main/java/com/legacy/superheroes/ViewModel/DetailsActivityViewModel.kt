package com.legacy.superheroes.ViewModel

import android.app.Application
import androidx.lifecycle.AndroidViewModel

class DetailsActivityViewModel(application: Application): AndroidViewModel(application) {

}