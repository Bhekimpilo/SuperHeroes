package com.legacy.superheroes.Model

data class Work(
    val base: String,
    val occupation: String
)