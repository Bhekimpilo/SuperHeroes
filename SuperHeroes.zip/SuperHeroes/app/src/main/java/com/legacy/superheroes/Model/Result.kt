package com.legacy.superheroes.Model

data class Result(
    val appearance: Appearance,
    val biography: Biography,
    val connections: Connections,
    val id: String,
    val image: Image,
    val name: String,
    val powerStats: Powerstats,
    val work: Work
)