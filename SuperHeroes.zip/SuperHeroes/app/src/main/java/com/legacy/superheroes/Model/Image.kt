package com.legacy.superheroes.Model

data class Image(
    val url: String
)