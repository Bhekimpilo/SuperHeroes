package com.legacy.superheroes.Model

data class SuperHeroModel(
    val response: String,
    val results: List<Result>,
    val resultsFor: String
)