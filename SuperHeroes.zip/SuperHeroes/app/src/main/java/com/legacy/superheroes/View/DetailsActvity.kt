package com.legacy.superheroes.View

class DetailsActvity {
}